# Tiny13_HV_resetter
Attiny13, reset fuse and the chip, uses High Voltage Serial programming mode

2018-MAR-07

schematic & physical connection
![alt text](Attiny13_reset_schematic_breadbroad.JPG)

reset and done  
![alt text](Attiny13_reset_Termnial.JPG)

source code  
https://github.com/xiaolaba/Tiny13_HV_resetter/blob/master/Tiny13_HV_resetter.ino

hex files  
https://github.com/xiaolaba/Tiny13_HV_resetter/blob/master/Tiny13_HV_resetter.ino.hex   
https://github.com/xiaolaba/Tiny13_HV_resetter/blob/master/Tiny13_HV_resetter.ino.with_bootloader.hex    

To embeds image to this read.me
'![alt text](http://url/to/img.png)
